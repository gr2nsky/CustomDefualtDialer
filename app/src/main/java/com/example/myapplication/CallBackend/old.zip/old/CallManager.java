package com.example.myapplication.CallBackend;

import android.telecom.Call;

import java.util.Observable;

/**
 * @author Yoon
 * @created 2021-09-17
 */
public class CallManager {

}
